package main;
import java.io.*;
import system.Screen;

public class Test {
	public static void main(String[] args) throws IOException {
        Screen screen = new Screen(8);
        screen.mainScreen(screen);
	}
}
