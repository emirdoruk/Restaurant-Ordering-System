package user;
import java.util.*;
import table.TableManagement;
import menu.Menu;
import system.endOfDay;
import order.Order;
import menu.Meal;
import table.Table;
import order.Receipt;

public class Waiter {
	static Scanner sc = new Scanner(System.in);
    private Menu m;
    private endOfDay ed;
    private TableManagement tm;
    private Order o;

    public Waiter(TableManagement tm, Menu m, endOfDay ed, Order o) {
        this.m = m;
        this.ed = ed;
        this.tm = tm;
        this.o = o;
    }
    
    public void loop(int id) {
    	while (true) {
            System.out.println("\n--------------------");
    		System.out.println("Please choose what you want to do: \n" +
 		   		   "1. Order\n" +
 		           "2. Table Management\n" +
 		   		   "3. Receipt\n" + 
 				   "4. Exit"); 
 		System.out.print("Your Choice: ");
 		int choice = Integer.parseInt(sc.nextLine());
 		switch (choice) {
 			case 1: 
 				order();
 				break;
 			case 2:
 				table(id);
 				break;
 			case 3:
 				receipt(id);
 				break;
 			case 4: 
 				return;
 			default:
 		        System.out.println("\n--------------------");
 				loop(id);
 				break;
 			}
    	}
    }
    
    public void order() {
    	while (true) {
            System.out.println("\n--------------------");
    		System.out.print("Please choose what you want to do: \n" +
 		   		   "1. Add Order\n" +
 		   		   "2. Remove Order\n" +
 		   		   "3. Cancel Order\n" +
 	   			   "4. Exit\n");
 		System.out.print("Your Choice: ");
 		int choice = Integer.parseInt(sc.nextLine());
 		switch (choice) {
 			case 1: 
 				m.printMenu();
 				List<List<Meal>> menuList = m.menuList();
 				System.out.println("Please write meals like this: 4.2.-2-ON.\nWrite 'END' when finished.\nMeals: ");
 				boolean endFlag = false;
 				while(endFlag == false) {
 					String currentMeal = sc.nextLine();
 					if (currentMeal.equalsIgnoreCase("end"))
 						endFlag = true;
 					else {
 						String[] strArr = currentMeal.split("-");
 						String[] mealNumber = strArr[0].split("\\.");
 						int type = Integer.parseInt(mealNumber[0]) -1;
 						int name = Integer.parseInt(mealNumber[1]) -1;
 						String mealName = menuList.get(type).get(name).name;
 						int quantity = Integer.parseInt(strArr[1]);
 						boolean customerNote = false;
 						if (strArr[2].equalsIgnoreCase("on"))
 							customerNote = true;
 						for (int i = 0; i < quantity; i++)
 							o.addMeal(m.findMeal(mealName), customerNote);
 					}
 				}	
 				tm.assignOrderToTable(o.getTableId(), o);
 				break;
 			case 2: 
 				o.printOrder(o);
 				System.out.print("Name of Meal: "); String mealName = sc.nextLine();
 				o.removeMeal(mealName);
 				break;
 			case 3: 
 				o.cancelOrder();
 				break;
 			case 4: 
 				return;
 			default:
 				order();
 				break;
 			}
    	}
    }
    
    public void table(int id) {
    	while (true) {
            System.out.println("\n--------------------");
    		System.out.print("Please choose what you want to do: \n" +
     		         "1. Close A Table\n" +
     		         "2. Reserve A Table\n" +
     		         "3. Merge Tables\n" +
   				 "4. Exit\n");
   		System.out.print("Your Choice: ");
   		int choice = Integer.parseInt(sc.nextLine());
   		switch (choice) {
   			case 1: 
   				ed.addPayment(id, tm.getPrice());
   				receipt(id);
   				tm.closeTable(id, ed);
   				break;
   			case 2: 
   				tm.reserveTable(id);
   				break;
   			case 3: 
   				int id1 = id;
   				System.out.print("Please write second table's id: "); int id2 = Integer.parseInt(sc.nextLine());
   				tm.mergeTables(id1, id2);
   				break;
   			case 4: 
   				return;
   			default:
   				table(id);
   				break;
   			}
    	}
    }
    
    public void receipt(int id) {
    	while (true) {
            System.out.println("\n--------------------");
    		System.out.println("Please choose what you want to do: \n" +
 		   		   "1. Print Receipt\n" +
 		   		   "2. Pay Full Receipt\n" +
 		   		   "3. Pay Split By Person\n" +
 		   		   "4. Pay Split For Person\n" + 
 		   		   "5. Exit");
 		System.out.print("Your Choice: ");
 		int choice = Integer.parseInt(sc.nextLine());
 	    Table t = tm.getTable(id);
 	    if (t != null || t.order != null) {
 	        Receipt r = new Receipt(t.order, id);
 	    	switch (choice) {
 	    		case 1: 
 	    			r.printFullReceipt(id);
 	    			break;
 	    		case 2:
 			        t.resetTable();
 			        break;
 	    		case 3: 
 			        System.out.print("Number of People: "); int personCount = Integer.parseInt(sc.nextLine());
 			        r.splitReceiptbyPerson(personCount);
 			        t.resetTable();
 			        break;
 	    		case 4: 
 			        System.out.print("Person Name: ");
 			        String name = sc.nextLine();
 			        Person person = new Person(name);
 			        Map<String, Integer> mealMap = new HashMap<>();
 			        System.out.println("Enter meals like 'Fries-2'. \nType END to finish.");
 			        while (true) {
 			            String line = sc.nextLine();
 			            if (line.equalsIgnoreCase("END")) break;
 			            String[] parts = line.split("-");
 			            if (parts.length == 2) {
 			                String mealName = parts[0].trim();
 			                int count = Integer.parseInt(parts[1].trim());
 			                mealMap.put(mealName, count);
 			            }
 			        }
 			        r.assignMeals(mealMap, person);
 			        r.splitReceiptforPerson();
 			        if (t.order.getOrder().isEmpty())
 			            t.resetTable();
 	    			break;
 	    		case 5: 
 	    			return;
 	    		default:
 		        	receipt(id);
 		        	break;		
 	    		}
 	    	}
 	    else
 	        System.out.println("No active order for Table " + id);
 	    return;
	    }
    }
}
