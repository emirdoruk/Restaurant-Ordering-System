package user;
import java.io.IOException;
import java.util.*;
import stock.Stock;
import menu.Menu;
import system.File;
import system.endOfDay;
import stock.Ingredient;
import stock.Stock;
import menu.Meal;

public class Manager {
	static Scanner sc = new Scanner(System.in);
    private Stock s;
    private Menu m;
    private endOfDay ed;
    private Login l;

    public Manager(Login l, Stock s, Menu m, endOfDay ed) {
        this.s = s;
        this.m = m;
        this.ed = ed;
        this.l = l;
    }
    
    public void loop() throws IOException {
    	while (true) {
    		System.out.println("\nPlease choose what you want to do: \n" +
 				   "1. Buy Ingredients\n" +
 				   "2. Update Menu\n" + 
 				   "3. Print End of Day\n" + 
 				   "4. Employee Operations\n" + 
 				   "5. Exit"); 
 		System.out.print("Your Choice: ");
 		int choice = Integer.parseInt(sc.nextLine());
 		switch (choice) {
 			case 1: 
 				System.out.print("Ingredient: "); String ing = sc.nextLine();
 				System.out.print("Count:      "); int count = Integer.parseInt(sc.nextLine());
 			    Ingredient ingredient = s.getIngredientByName(ing);
 			    ingredient.setCount(ingredient.getCount() + count);
 			    File.writeStock(s.stock, "ingredients.csv");
 			    break;
 			case 2: 
 				m.printMenu();
 				updateMenu();
 				break;
 			case 3:
 				ed.save();
 				break;
 			case 4:
 				employeeOps();
 				break;
 			case 5: 
 				return;
 			default:
 	            System.out.println("\n--------------------");
 				loop();
 				break;
 			}
    	}
    }
    
    public void updateMenu() throws IOException {
    	while (true) {
            System.out.println("\n--------------------");
    		System.out.println("\nPlease choose what you want to do:\n" +
 		           "1. Remove A Meal\n" +
 		           "2. Add New Meal\n" + 
 				   "3. Update A Meal\n" + 
 		           "4. Exit");
 		System.out.print("Your Choice: "); int choice1 = Integer.parseInt(sc.nextLine());
 		System.out.print("Name of Meal: "); String mealName = sc.nextLine();
 		Meal meal = m.findMeal(mealName);
 		switch (choice1) {
 			case 1: 
 		    	m.removeMeal(mealName);
 		        File.writeMeals(m.getMeals(), "meals.csv");
 		        break;
 			case 2: 
 		        m.addMeal(meal);
 		        File.writeMeals(m.getMeals(), "meals.csv");
 		        break;
 			case 3: 
 				meal.updateMeal(meal, s);
 		        File.writeMeals(m.getMeals(), "meals.csv");
 		        break;
 			case 4:
 				return;
 			default:
 				updateMenu();
 				break;
 			}
    	}
    }
    
    public void employeeOps() throws IOException {
    	while (true) {
            System.out.println("\n--------------------");
    		System.out.println("Please choose what you want to do: \n" +
 				   "1. Add New Employee\n" +
 				   "2. Change Role\n" + 
 				   "3. Fire Employee\n" + 
 				   "4. Exit"); 
 		System.out.print("Your Choice: ");
 		int choice = Integer.parseInt(sc.nextLine());
 		switch (choice) {
 		case 1: 
 	    	System.out.print("Employee Name: "); String name1 = sc.nextLine();
 	    	System.out.print("Employee Role:"); String role1 = sc.nextLine();
 	    	System.out.print("Employee Password: "); String password1 = sc.nextLine();
 			l.addNewPerson(name1, role1, password1, false);
 			break;
 		case 2: 
 	    	System.out.print("Employee Name: "); String name2 = sc.nextLine();
 	    	System.out.print("Employee Password: "); String password2 = sc.nextLine();
 	    	System.out.print("New Role: "); String newRole = sc.nextLine();
 	    	l.changeRole(name2, newRole, password2);
 	    	break;
 		case 3:
 	    	System.out.print("Employee Name: "); String name3 = sc.nextLine();
 	    	System.out.print("Employee Password: "); String password3 = sc.nextLine();
 			l.firePerson(name3, password3);
 			break;
 		case 4:
 			return;
 		default:
 			employeeOps();
 			break;
 			}
    	}
    }
}
