package user;
import java.util.Scanner;
import stock.Stock;
import menu.Menu;
import table.TableManagement;

public class Cook {
	static Scanner sc = new Scanner(System.in);
    public Stock s;
    public Menu m;
    public TableManagement tm;

    public Cook(TableManagement tm, Menu m, Stock s) {
        this.m = m;
        this.s = s;
        this.tm = tm;
    }
    
    public void loop() {
		System.out.println("Please choose what you want to do: \n" +
		   		   "1. View Kitchen Screen\n" +
		   		   "2. Give Ready For An Order\n" +
				   "3. Exit"); 
		System.out.print("Your Choice: ");
		int choice = Integer.parseInt(sc.nextLine());
		switch (choice) {
			case 1: 
				tm.printAllOrders();
				break;
			case 2:
				System.out.print("TableId:   "); int id = Integer.parseInt(sc.nextLine());
				System.out.print("Meal Name: "); String name = sc.nextLine();
				tm.markMealReady(id, name);
				break;
			case 3:
				break;
			default:        
				System.out.println("\n--------------------");
				loop();
				break;
		}
    }
}
