package user;

public class Person {
	public String name;
    public String role;
    public String password;
    public boolean logged;

    public Person(String name, String role, String password) {
        this.name = name;
        this.role = role;
        this.password = password;
        this.logged = false;
    }
    
    public Person(String name) {
        this.name = name;
        this.role = "Customer";
        this.password = null;
        this.logged = true;
    }
    
    public void changerole(String newRole) {
    	this.role = newRole;
    }
    
    public void changeLog() {
    	boolean flag = this.logged;
    	if (flag == true) this.logged = false;
    	else this.logged = true;
    }
    
    public void setName(String name) {
    	this.name = name;
    }
    
    public void setRole(String role) {
    	this.role = role;
    }
    
    public void setPassword(String password) {
    	this.password = password;
    }
}
