package user;
import java.io.IOException;
import java.util.*;

import system.File;

public class Login {
	public List<Person> people;
	
    public Login(List<Person> people) {
        this.people = new ArrayList<>(people);
    }
	
    public Person access(String name, String password) {
        for (Person person : people) {
            if (person.name.equalsIgnoreCase(name) &&
                person.password != null &&
                person.password.equals(password)) {
                person.logged = true;
                return person;
            }
        }
        return null;
    }
    
    public void changeRole(String name, String newRole, String password) {
        for (Person person : people) {
            if (person.name.equalsIgnoreCase(name) && person.password.equalsIgnoreCase(password)) {
                person.changerole(newRole);
            }
        }
    }
    
    public boolean addNewPerson(String name, String role, String password, boolean read) throws IOException {
    	if (!read) {
            boolean success = addNewPerson(name, role, password, true);
            if (success)
                File.appendPerson(new Person(name, role, password), "people.csv");
    	}
        for (Person person : people)
            if (person.name.equalsIgnoreCase(name) && person.password.equalsIgnoreCase(password))
                return false;
        people.add(new Person(name, role, password));
        return true;    	
    }
    
    public void firePerson(String name, String password) throws IOException {
        Person remove = null;   
        for (Person person : people)
            if (person.name.equalsIgnoreCase(name) && person.password.equalsIgnoreCase(password)) {
                File.deletePerson(person, "people.csv");
                remove = person;
                break;
            }
        if (remove != null)
            people.remove(remove);
    }
}
