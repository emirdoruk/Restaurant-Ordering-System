package system;
import java.io.*;
import java.util.*;
import menu.*;
import order.*;
import user.*;
import table.*;
import stock.*;

public class Screen {
	static Scanner sc = new Scanner(System.in);
	List<Person> p;
	Login l;
    endOfDay ed;
    TableManagement tm;
    Stock s;
    Menu m;
    
    public Screen(int tableCount) throws IOException{
    	this.p = File.readPeople("people.csv");
    	this.l = new Login(p);
    	this.ed =  new endOfDay();
    	this.tm = new TableManagement(tableCount);
        List<Object> lists = File.stockNmenu("ingredients.csv", "meals.csv");
    	this.s = (Stock) lists.get(0);
        this.m = (Menu) lists.get(1);
    }
    
    public void mainScreen(Screen screen) throws IOException {
        System.out.println("\n----- Login Screen -----");
		System.out.print("Name:     "); String name = sc.nextLine();
        System.out.print("Password: "); String password = sc.nextLine();
        Person user = l.access(name, password);
        
        if (user == null) {
            System.out.println("Invalid name or password. Please try again.\n");
            mainScreen(screen);
            return;
        }
        
        switch (user.role.toLowerCase()) {
        case "manager": case "m":
            managerScreen(screen.l, screen.s, screen.m, screen.ed);
            break;
        case "waiter": case "w":
            waiterScreen(screen.s, screen.m, screen.tm, screen.ed);
            break;
        case "cook": case "c":
            cookScreen(screen.s, screen.m, screen.tm);
            break;
        default:
            break;
        }
        mainScreen(screen);
    }
    
    public void managerScreen(Login l, Stock s, Menu m, endOfDay ed) throws IOException {
		System.out.println("\n----- Manager Screen -----");
		Manager managerScreen = new Manager(l, s, m, ed);
		managerScreen.loop();
    }

	public static void waiterScreen(Stock s, Menu m, TableManagement tm, endOfDay ed) {
		System.out.println("\n----- Waiter Screen -----");
		int cTableId = -1;
	    while (true) {
	        System.out.print("Please choose a table: ");
	        String input = sc.nextLine();
            cTableId = Integer.parseInt(input);
            if (cTableId >= 1 && cTableId <= tm.tables.size())
                break;
            else
                System.out.println("Invalid table number. Please choose a number between 1 and " + tm.tables.size() + ".");
	    }
    	Order o = new Order(cTableId);
    	Waiter waiterScreen = new Waiter(tm, m, ed, o);
    	waiterScreen.loop(cTableId);
	}
	
	public static void cookScreen(Stock s, Menu m, TableManagement tm) {
		System.out.println("\n----- Kitchen Screen -----");
		Cook cookScreen = new Cook(tm, m, s);
		cookScreen.loop();
	}
}
