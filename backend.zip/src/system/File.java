package system;
import java.io.*;
import java.util.*;
import stock.Ingredient;
import menu.Meal;
import user.Person;
import menu.Menu;
import stock.Stock;

public class File {
    public static List<String[]> readCSV(String filename) throws IOException {
        List<String[]> data = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new FileReader(filename));
        String line = reader.readLine(); 
        while ((line = reader.readLine()) != null) {
            String[] parts = line.split(";");
            data.add(parts);
        }
        reader.close();
        return data;
    }
    
	public static List<Ingredient> readIngredients(String file, String type) throws IOException {
		List<String[]> ingredientList = readCSV(file);
	    List<Ingredient> ingredients = new ArrayList<>();
	    for (int i = 0; i < ingredientList.size(); i++) {
	    	String[] row = ingredientList.get(i);
	        if (row.length >= 2) {
	            String name = row[0].trim();
	            double price = 0.0;
	            if (type.equalsIgnoreCase("default"))
		            if (!row[2].isEmpty())
		            	price = Double.parseDouble(row[2].trim().replace(",", "."));
	            if (type.equalsIgnoreCase("extra"))
		            if (!row[1].isEmpty())
		            	price = Double.parseDouble(row[1].trim().replace(",", "."));
	            ingredients.add(new Ingredient(name, price));
	        }
	    }
	    return ingredients;
	    
	}
	
	public static List<Meal> readMeals(String file, List<Ingredient> ingredient) throws IOException {
	    List<String[]> mealList = readCSV(file);
	    List<Meal> meals = new ArrayList<>();
	    for (String[] row : mealList) {
        	List<Ingredient> ingredients = new ArrayList<>();
            String name = row[0].trim();
            String type = row[1].trim();
            int count = Integer.parseInt(row[3].trim());
            double[] price = new double[3];
            if (type.equals("4") || type.equals("5")) {
            	double ingPrice = 0;
            	for (int i= 0; i < ingredient.size(); i++)
            		if (ingredient.get(i).name.equals(name)) 
            			ingPrice = ingredient.get(i).getPrice();
            	Ingredient ing = new Ingredient(name, ingPrice);
                ing.setCount(count);
                ingredients.add(ing);  
                price[0] = ingPrice;
	            for (int j = 0; j < 2; j++)
	                price[j + 1] = Double.parseDouble(row[5 + j].trim());
            }
            else {
	            String ingredientFileName = row[2].trim();
	            List<String[]> ingredientData = readCSV("meals\\" + ingredientFileName + ".csv");
	            for (int j = 0; j < ingredientData.size(); j++) {
	                String[] ingRow = ingredientData.get(j);
	                if (ingRow.length >= 2) {
	                    String ingName = ingRow[0].trim();
	                    Ingredient ing = new Ingredient(ingName, Double.MIN_VALUE); // sabit ürün olduğu için min value
	                    ing.setCount(count);
	                    ingredients.add(ing);
	                }
	            }
	            for (int j = 0; j < 3; j++)
	                price[j] = Double.parseDouble(row[4 + j].trim());
            }
            meals.add(new Meal(name, type, ingredients, count, price));
	    }
	    return meals;
	}
	
	public static List<Person> readPeople(String file) throws IOException{
		List<String[]> personList = readCSV(file);
	    List<Person> people = new ArrayList<>();
	    for (int i = 0; i < personList.size(); i++) {
	    	String[] row = personList.get(i);
	        if (row.length >= 2) {
	            String name = row[0].trim();
	            String role = row[1].trim();
	            String password = row[2].trim();
	            people.add(new Person(name, role, password));
	        }
	    }
	    return people;
	}

    public static void writePeople(String filename, List<String[]> strList) throws IOException {
		List<Person> people = new ArrayList<>();
    	for (int i = 0; i < strList.size(); i++)
			people.add(new Person(strList.get(i)[0], strList.get(i)[1], strList.get(i)[2]));
        BufferedWriter writer = new BufferedWriter(new FileWriter(filename));
        writer.write("Name;Role;Password");
        writer.newLine();
        for (Person p : people) {
            writer.write(p.name + ";" + p.role + ";" + p.password);
            writer.newLine();
        }
        writer.close();
    }

    public static void appendPerson(Person p, String filename) throws IOException {
		List<String[]> personList = readCSV(filename);
		String[] personArr = new String[3];
		personArr[0] = p.name; personArr[1] = p.role; personArr[2] = p.password;
		personList.add(personArr);
		writePeople(filename, personList);
    }
    
    public static void deletePerson(Person p, String filename) throws IOException {
		List<String[]> oldPersonList = readCSV(filename);
		List<String[]> newPersonList = new ArrayList<>();
		for (int i = 0; i < oldPersonList.size(); i++)
			if (!oldPersonList.get(i)[0].equals(p.name) && !oldPersonList.get(i)[1].equals(p.role) && !oldPersonList.get(i)[2].equals(p.password))
				newPersonList.add(oldPersonList.get(i));
        writePeople(filename, newPersonList);
    }

    public static void writeStock(List<Ingredient> stock, String filename) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(filename));
        writer.write("Name;ExtraPrice;DefaultPrice");
        writer.newLine();
        for (Ingredient ing : stock) {
            writer.write(ing.name + ";" + ing.getPrice() + ";" + ing.getPrice());
            writer.newLine();
        }
        writer.close();
    }

    public static void writeMeals(List<Meal> meals, String filename) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(filename));
        writer.write("Name;Type;IngredientFile;Count;Price;Discount;DiscountType");
        writer.newLine();
        for (Meal meal : meals) {
            writer.write(meal.name + ";" + meal.type + ";null;" + meal.count + ";" +
                         meal.price[0] + ";" + meal.price[1] + ";" + meal.price[2]);
            writer.newLine();
        }
        writer.close();
    }
    
	public static List<Object> stockNmenu(String ingFile, String mealFile) throws IOException {
		List<Object> lists = new ArrayList<>();
		// Stock
		List<Ingredient> ingredient = readIngredients(ingFile, "default");
		Stock stock = new Stock();
		for (int i = 0; i < ingredient.size(); i++)
			stock.addIngredient(ingredient.get(i), 20);
		lists.add(stock);
		
		// Menu
		List<Meal> meal = readMeals(mealFile ,ingredient); 
		Menu menu = new Menu();
		for (int i = 0; i < meal.size(); i++)
			menu.addMeal(meal.get(i));
		lists.add(menu);
		
		return lists;
	}
}
