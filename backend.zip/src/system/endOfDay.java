package system;
import java.io.*;
import java.time.*;
import java.util.*;

public class endOfDay {
    ArrayList<String> allOrdersPrices;
    double revenue;
    
    public endOfDay() {
        this.allOrdersPrices = new ArrayList<>();
        this.revenue = 0;
    }
    
    public void addPayment(int tableId, double amount) {
    	revenue += amount;
    	allOrdersPrices.add("Table " + tableId + " paid " + amount + "₺");
    }

    public void reset() {
    	revenue = 0;
    	allOrdersPrices.clear();
    }
    
    public void save() throws IOException {
        LocalDate today = LocalDate.now();
        String line = today + " - " + revenue + "₺\n";
        FileWriter writer = new FileWriter("endOfDay_Data.txt", true);
        writer.write(line);
        writer.close();
        reset();
    }
}
