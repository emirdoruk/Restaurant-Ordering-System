package stock;

public class Ingredient {
	public String name;
	public int count;
	public double price;
	public boolean available;
	
    public Ingredient(String name, double price) {
    	this.name = name;
    	this.count = 1;
    	this.price = price;
    	this.available = true;
    }
    
	public void setCount(int count) {
	    this.count = count;
	    setAvailable();
	}
	
	public void setAvailable() {
		if (this.count == 0)
			this.available = false;
	}
	
	public double getPrice() {
		return price;
	}
    
	public int getCount() {
		return count;
	}
}
