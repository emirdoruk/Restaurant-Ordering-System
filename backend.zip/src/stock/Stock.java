package stock;
import java.util.*;
import menu.Menu;
import menu.Meal;
import order.Order;

public class Stock {
    public static List<Ingredient> stock;
    public Menu menu;
    
    public Stock() {
        stock = new ArrayList<>();
    }

    public boolean isAvailable(String name, int requiredAmount) {
    	for (int i = 0; i < stock.size(); i++) {
    		Ingredient ingredient = stock.get(i);
            if (ingredient.name.equalsIgnoreCase(name))
                return ingredient.count >= requiredAmount;
    	}
        return false;
    }

    public void useIngredients(Order order) {
    	for (int i = 0; i < order.selectedMeals.size(); i++) {
    		Meal meal = order.selectedMeals.get(i);
    		for (int j = 0; j < meal.ingredients.size(); j++) {
    			Ingredient usedItem = meal.ingredients.get(j);
    			for (int h = 0; h < stock.size(); h++) {
    				Ingredient stockItem = stock.get(h);
                    if (stockItem.name.equalsIgnoreCase(usedItem.name)) {
                        int newCount = stockItem.count - usedItem.count * meal.count;
                        stockItem.setCount(Math.max(newCount, 0));
                        break;
                    }
    			}
    		}
    	}
    }
    
    public void addIngredient(Ingredient ingredient, int count) {
        for (int i = 0; i < stock.size(); i++) {
            Ingredient existing = stock.get(i);
            if (existing.name.equalsIgnoreCase(ingredient.name)) {
                existing.setCount(existing.count + count);
                return;
            }
        }
        ingredient.setCount(count);
        stock.add(ingredient);
    }
    
    public static Ingredient getIngredientByName(String name) {
        for (Ingredient ingredient : stock) {
            if (ingredient.name.equalsIgnoreCase(name)) {
                return ingredient;
            }
        }
        return null;
    }

    
    public void printStock() {
        System.out.println("----- Current Stock -----");
        for (int i = 0; i < stock.size(); i++) {
        	Ingredient ingredient = stock.get(i);
            System.out.println(ingredient.name + " x" + ingredient.count);
        }
    }    

}
