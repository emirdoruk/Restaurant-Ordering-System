package menu;
import java.util.*;

public class Menu {
    List<Meal> meals;
	
    public Menu() {
        meals = new ArrayList<>();
    }
    
    public List<Meal> getMeals() {
        return meals;
    }
    
    public void addMeal(Meal meal) {
        meals.add(meal);
    }

    public void removeMeal(String mealName) {
        for (int i = 0; i < meals.size(); i++)
            if (meals.get(i).name.equalsIgnoreCase(mealName)) {
                meals.remove(i);
                break;
            }
    }
    
    public Meal findMeal(String name) {
        for (Meal m : meals) {
            if (m.name.equalsIgnoreCase(name)) return m;
        }
        return null;
    }
    
    public List<Meal> getAvailableMeals() {
        List<Meal> available = new ArrayList<>();
        for (Meal meal : meals) {
            if (meal.isAvailable()) {
                available.add(meal);
            }
        }
        return available;
    }

    public void printMenu() {
        for (int i = 0; i < meals.size(); i++)
            for (int j = i + 1; j < meals.size(); j++) {
                Meal meal1 = meals.get(i);
                Meal meal2 = meals.get(j);
                if (compare(meal1.type, meal2.type) > 0 || (meal1.type.equalsIgnoreCase(meal2.type) && compare(meal1.name, meal2.name) > 0)) {
                    meals.set(i, meal2);
                    meals.set(j, meal1);
                }
            }
        String currentType = "";
        for (int i = 0; i < meals.size(); i++) {
        	Meal meal = meals.get(i);
            if (!meal.isAvailable()) continue;
            if (!meal.type.equalsIgnoreCase(currentType)) {
                currentType = meal.type;
                String text = "";
                if (currentType.equals("4")) text += "Appetizer";
                if (currentType.equals("1")) text += "Burger";
                if (currentType.equals("2")) text += "Chicken Burger";
                if (currentType.equals("3")) text += "Hot Dog";
                if (currentType.equals("5")) text += "Drink";
                System.out.println("\n" + currentType + ". "+ text);
            }
            int x = i;
            if (currentType.equals("2")) x -= 11;
            if (currentType.equals("3")) x -= 16;
            if (currentType.equals("4")) x -= 20;
            if (currentType.equals("5")) x -= 25;
            System.out.println(currentType + "." + (x + 1) + ". " + meal.name + " - " + meal.getPrice() + "₺");
        }
    }
    
    private int compare(String meal1, String meal2) {
        meal1 = meal1.toLowerCase();
        meal2 = meal2.toLowerCase();
        int length = Math.min(meal1.length(), meal2.length());
        for (int i = 0; i < length; i++) {
            char chr1 = meal1.charAt(i);
            char chr2 = meal2.charAt(i);
            if (chr1 != chr2) {
                return chr1 - chr2;
            }
        }
        return meal1.length() - meal2.length();
    }

    public List<List<Meal>> menuList(){
    	List<List<Meal>> menu = new ArrayList<>();
    	List<Meal> b = new ArrayList<>(); menu.add(b);
    	List<Meal> cb = new ArrayList<>(); menu.add(cb);
    	List<Meal> hd = new ArrayList<>(); menu.add(hd);
    	List<Meal> a = new ArrayList<>(); menu.add(a);
    	List<Meal> d = new ArrayList<>(); menu.add(d);
    	
        for (int i = 0; i < meals.size(); i++)
            for (int j = i + 1; j < meals.size(); j++) {
                Meal meal1 = meals.get(i);
                Meal meal2 = meals.get(j);
                if (compare(meal1.type, meal2.type) > 0 || (meal1.type.equalsIgnoreCase(meal2.type) && compare(meal1.name, meal2.name) > 0)) {
                    meals.set(i, meal2);
                    meals.set(j, meal1);
                }
            }
        String currentType = "";
        for (int i = 0; i < meals.size(); i++) {
        	Meal meal = meals.get(i);
            if (!meal.isAvailable()) continue;
            if (!meal.type.equalsIgnoreCase(currentType)) {
                currentType = meal.type;
            }
            menu.get(Integer.parseInt(currentType) - 1).add(meal);
        }
        return menu;
    }
    
}
