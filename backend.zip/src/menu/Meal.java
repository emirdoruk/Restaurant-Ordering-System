package menu;
import java.io.*;
import java.util.*;
import stock.Ingredient;
import stock.Stock;

public class Meal {
	public String name;
	public String type;
	public List<Ingredient> ingredients;
	public int count;
	public boolean ready;
	public double[] price; // 0 price // 1 discount // 2 discount type / 0 % / 1 - 
	public String customerNote;

	public static Scanner sc = new Scanner(System.in);
	
	public Meal(String name, String type, List<Ingredient> ingredients, int count, double[] price) {
		this.name = name;
		this.type = type;
	    this.ingredients = ingredients;
	    this.count = count;
	    this.ready = false;
	    this.price = price;
	    this.customerNote = "";
	}
	
	public void printIngredients() {
	    for (Ingredient ingredient : ingredients) {
	        System.out.println(ingredient.name);
	    }
	}
	
	public void setReady() {
	    this.ready = true;
	}	
	
	public boolean isAvailable() {
	    for (Ingredient ingredient : ingredients) {
	        Ingredient stockIngredient = Stock.getIngredientByName(ingredient.name);
	        if (stockIngredient == null || stockIngredient.count < ingredient.count) {
	            return false;
	        }
	    }
	    return true;
	}
	
	public void discount(double[] prices) {
	    double price = prices[0];
	    double discount = prices[1];
	    double type = prices[2];
	    if (type == 0) 
	        price -= discount;
	    else if (type == 1)
	        price = price * (1 - discount / 100.0);
	    prices[0] = price;
	}

	
	public double getPrice() {
		return price[0];
	}
	
	public void updateMeal(Meal meal, Stock s) throws IOException {
		System.out.print("Please choose what you want to do:\n" +
		   		   "1. Update Name\n" +
		   		   "2. Update Price\n" + 
		   		   "3. Update Discount\n" + 
		   		   "4. Update Ingredients\n" + 
		   		   "Your Choice: ");
		int x = Integer.parseInt(sc.nextLine());
		System.out.print("Object's New Value: ");
		Object newObj = (Object) sc.nextLine();
		if (x == 1) meal.name = (String) newObj;
		if (x == 2) meal.price[0] = (Double) newObj;
		if (x == 3) {
			char[] discount = newObj.toString().toCharArray();
			double[] d = new double[3];
			char type = discount[2];
			if (type == '%') d[2] = 0;
			else d[2] = 1;
			String numberStr = new String(discount, 1, discount.length - 1);
			d[1] = Double.parseDouble(numberStr);
			d[0] = meal.getPrice();
			meal.discount(d);
		}
		if (x == 4) {			
			System.out.println("Ingredients:");
			System.out.println("Please write ingredients like this: Onion-5");
			System.out.println("Write 'END' when finished.");
		    List<Ingredient> ingList = new ArrayList<>();
		    while (true) {
		        String line = sc.nextLine();
		        if (line.equalsIgnoreCase("END")) break;
				String[] parts = line.split("-");
				String ingName = parts[0]; int ingCount = Integer.parseInt(parts[1]);
				Ingredient original = s.getIngredientByName(ingName);
				Ingredient newIng;
				if (original == null)
					newIng = new Ingredient(ingName, 6.83);
				else
					newIng = new Ingredient(original.name, original.price);
				ingList.add(newIng);
		    }
		    meal.ingredients = ingList;
		    return;
		}

	}
	
	public void writeNote(String note) {
		this.customerNote = note;
	}

}
