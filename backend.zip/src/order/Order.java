package order;
import java.util.*;
import table.Table;
import menu.Meal;

public class Order {
    public ArrayList<Meal> selectedMeals;
    public Scanner sc = new Scanner(System.in);
    public Table table;
    
    public Order(int tableId) {
        selectedMeals = new ArrayList<>();
        table = new Table(tableId);
    }

    public ArrayList<Meal> getOrder() {
        return selectedMeals;
    }
    
    public Table getTable() {
    	return table;
    }
    
    public int getTableId() {
    	return getTable().getTableId();
    }
    
    public void addMeal(Meal selectedMeal, boolean customerNote) {
        if (customerNote){
    		String note = sc.nextLine();
    		customerNote = false;
            if (!note.equalsIgnoreCase("end"))
                selectedMeal.customerNote = note;  
        }
    	selectedMeals.add(selectedMeal);
    }

    public void removeMeal(String removedMeal) {
    	String[] arr = removedMeal.split("-");
    	String mealName = arr[0];
    	int mealCount = Integer.parseInt(arr[1]);
    	
        for (int i = 0; i < selectedMeals.size(); i++) {
            if (selectedMeals.get(i).name.equalsIgnoreCase(mealName)) {
            	for (int j = 0; j < mealCount; j++)
            		selectedMeals.remove(i);
                return;
            }
        }
    }

    public void cancelOrder() {
        selectedMeals.clear();
        System.out.println("Order cancelled.");
    }

    public boolean setMealReady(String mealName) {
        for (Meal meal : selectedMeals)
            if (meal.name.equalsIgnoreCase(mealName)) {
                meal.setReady();
                return true;
            }
        return false;
    }
    
    public boolean allMealsReady() {
        for (Meal meal : selectedMeals) {
            if (!meal.ready)
                return false;
        }
        return true;
    }
    
    public void displayonKitchen() {
        System.out.println("----- Kitchen Display -----");
        for (Meal meal : selectedMeals) {
            System.out.print(meal.name + " x" + meal.count);
            if (meal.ready) 
                System.out.println(" [Ready]");
            else 
                System.out.println(" [Pending]");

        }
    }
    
    public double getTotalPrice() {
        double total = 0;
        for (Meal meal : selectedMeals) {
        	double price = 0;
        	if (meal.price[2] == 0)
        		price = (meal.price[0]*(100-meal.price[1])/100);
        	else 
        		price = meal.price[0]-meal.price[1];
            total += price * meal.count;
        }
        return total;
    }
    
    public void printOrder(Order o) {
        List<String> mealNames = new ArrayList<>();
        List<Integer> mealCount = new ArrayList<>();
        for (int i = 0; i < selectedMeals.size(); i++) {
        	Meal meal = selectedMeals.get(i);
            if (!meal.isAvailable()) continue;

            if (!mealNames.contains(meal.name)) {
            	mealNames.add(meal.name);
            	mealCount.add(1);
            }
            else {
                int index = mealNames.indexOf(meal.name);
                int count = (int) mealCount.get(index);
                mealCount.set(index, count + 1);
            }
        }
        for (int i = 0; i < mealNames.size(); i++) {
        	String name = mealNames.get(i);
        	int count = mealCount.get(i);
            String note = "";
            for (Meal meal : selectedMeals) {
                if (meal.name.equalsIgnoreCase(name) && meal.customerNote != null && !meal.customerNote.isEmpty()) {
                    note = meal.customerNote;
                    break;
                }
            }
            System.out.println((i + 1) + ". " + name + " - " + count + "\n  -Note: " + note);
        }
    }
}