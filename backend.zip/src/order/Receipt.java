package order;
import java.util.*;
import user.Person;
import menu.Meal;

public class Receipt {
    public Order order;
    public int tableId;
    public Map<Person, List<Meal>> individualBills;

    public Receipt(Order order, int tableId) {
        this.order = order;
        this.tableId = tableId;
        this.individualBills = new HashMap<>();
    }

    public void printFullReceipt(int tableId) {
        System.out.println("----- Full Receipt of Table " + tableId + " -----");
        for (Meal meal : order.getOrder()) {
        	double price = 0;
        	if (meal.price[2] == 0)
        		price = (meal.price[0]*(100-meal.price[1])/100);
        	else 
        		price = meal.price[0]-meal.price[1];
            double subtotal = price * meal.count;
            System.out.println(meal.name + " x" + meal.count + " = (" + meal.getPrice() + " x " + meal.count + ") = " + subtotal + "₺");
        }
        System.out.println("Total: " + order.getTotalPrice() + "₺");
    }

    public void splitReceiptbyPerson(int personCount) {
        double share = order.getTotalPrice() / personCount;
        System.out.println("Split Payment: Each person pays " + share + "₺");
    }

    public void assignMeals(Map<String, Integer> mealQuantities, Person person) {
        individualBills.putIfAbsent(person, new ArrayList<>());
        for (Map.Entry<String, Integer> entry : mealQuantities.entrySet()) {
            String mealName = entry.getKey();
            int quantity = entry.getValue();
            for (int i = 0; i < order.getOrder().size(); i++) {
                Meal meal = order.getOrder().get(i);
                if (meal.name.equalsIgnoreCase(mealName)) {
                    if (meal.count >= quantity) {
                        Meal personMeal = new Meal(meal.name, meal.type, meal.ingredients, quantity, meal.price);
                        individualBills.get(person).add(personMeal);
                        meal.count -= quantity;
                        if (meal.count == 0)
                            order.getOrder().remove(i);
                    }
                    else
                        System.out.println("Error: Only " + meal.count + " of " + meal.name + " available in order.");
                    break;
                }
            }
        }
    }

    public void splitReceiptforPerson() {
        for (Person person : individualBills.keySet()) {
            List<Meal> meals = individualBills.get(person);
            if (meals == null || meals.isEmpty()) continue;
            System.out.println("\n" + person.name + "'s Bill:");
            double total = 0;
            for (Meal meal : meals) {
            	double price = 0;
            	if (meal.price[2] == 0)
            		price = (meal.price[0]*(100-meal.price[1])/100);
            	else 
            		price = meal.price[0]-meal.price[1];
                double subtotal = price * meal.count;
                System.out.println("+ " + meal.name + " x" + meal.count + " = (" + meal.price + " x " + meal.count + ") = " + subtotal + "₺");
                total += subtotal;
            }
            System.out.println("Total: " + total + "₺");
        }
    }

    public void printRemaining() {
        if (order.getOrder().isEmpty()) {
            System.out.println("\nAll meals have been paid. No remaining unpaid meals.");
            return;
        }
        System.out.println("\n----- Remaining Meals -----");
        for (Meal meal : order.getOrder()) {
        	double price = 0;
        	if (meal.price[2] == 0)
        		price = (meal.price[0]*(100-meal.price[1])/100);
        	else 
        		price = meal.price[0]-meal.price[1];
            double subtotal = price * meal.count;
            System.out.println("+ " + meal.name + " x" + meal.count + " = (" + meal.price + " x " + meal.count + ") = " + subtotal + "₺");
        }
        System.out.println("Subtotal: " + order.getTotalPrice() + "₺");
    }
}
