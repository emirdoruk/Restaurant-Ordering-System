package table;
import java.util.*;
import order.Order;
import menu.Meal;
import system.endOfDay;

public class TableManagement {
    public List<Table> tables;
    
    public TableManagement(int numberOfTables) {
        tables = new ArrayList<>();
        for (int i = 1; i <= numberOfTables; i++)
            tables.add(new Table(i));
    }
    
    public int getNumberofTable() {
    	return tables.size();
    }
    public void assignOrderToTable(int tableId, Order order) {
        Table table = getTable(tableId);
        if (table == null) return;

        if (table.order == null)
            table.assignOrder(order);
        else
            for (Meal m : order.getOrder())
                table.order.addMeal(m, false); 
        table.status = "Occupied";
    }
    
    public void closeTable(int tableId, endOfDay list) {
        Table table = getTable(tableId);
        if (table != null && table.order != null) {
            double paid = table.order.getTotalPrice();
            list.addPayment(tableId, paid);
            table.resetTable();
            System.out.println("Table " + tableId + " closed. Payment of " + paid + "₺ recorded.");
        }
    }

    public void reserveTable(int tableId) {
        Table table = getTable(tableId);
        if (table != null && table.status.equals("Empty")) {
            table.reserveTable();
            System.out.println("Table " + tableId + " reserved.");
        } 
        else
            System.out.println("Table cannot be reserved.");
    }
    

    public void mergeTables(int id1, int id2) {
        Table table1 = getTable(id1);
        Table table2 = getTable(id2);
        if (table1 != null && table2 != null && table1.order != null && table2.order != null) {
            for (Meal m : table2.order.getOrder())
                table1.order.addMeal(m, false);
            table2.resetTable();
            System.out.println("Tables " + id1 + " and " + id2 + " have been merged into Table " + id1);
        }
        else
            System.out.println("Tables cannot be merged.");
    }
    
    public Table getTable(int id) {
        for (Table table : tables)
            if (table.tableId == id)
                return table;
        System.out.println("Table " + id + " not found.");
        return null;
    }
    
    public double getPrice() {
        double total = 0.0;
        for (Table table : tables) {
            if (table.order != null)
                total += table.order.getTotalPrice();
        }
        return total;
    }

    public void printAllOrders() {
        for (Table table : tables) {
            if (table.order != null) {
                System.out.println("Table " + table.tableId + " (" + table.status + "):");
                for (Meal meal : table.order.getOrder()) {
                    System.out.println(" - " + meal.name + " x" + meal.count + "\n   " + meal.customerNote);
                }
                System.out.println();
            }
        }
    }
    
    public void markMealReady(int tableId, String mealName) {
        Table table = getTable(tableId);
        if (table != null && table.order != null) {
            boolean updated = table.order.setMealReady(mealName);
            if (updated)
                System.out.println(mealName + " at Table" + tableId + " marked as READY.");
            else
                System.out.println(mealName + " not found in Table" + tableId + "'s order.");
        } 
        else
            System.out.println("No active order for Table " + tableId + ".");
    }

}
