package table;
import order.Order;
import order.Receipt;

public class Table {
    int tableId;
    public String status; // "Empty", "Occupied", "Reserved"
    public Order order;
    public Receipt receipt;
    
    public Table(int tableId) {
    	this.tableId = tableId;
        this.status = "Empty";
        this.order = null;
        this.receipt = null;	
    }
    
    public void reserveTable() {
    	this.status = "Reserve";
    }
    
    public void resetTable() {
    	this.status = "Empty";
    	this.order = null;
    }
    
    public void assignOrder(Order order) {
        this.order = order;
        this.status = "Occupied";
        this.receipt = new Receipt(order, order.getTableId());
    }
    
    public double getPrice() {
    	return order.getTotalPrice();
    }
    
    public void setId(int id) {
    	this.tableId = id;
    }
    
    public int getTableId() {
    	return this.tableId;
    }
}
